// var audio = document.createElement('audio');
// audio.setAttribute('src', 'sound.mp3');
// audio.loop = true;
// audio.play();

var audio = document.createElement('audio');
audio.setAttribute('src', 'sound.mp3');
audio.loop = true;
audio.play();


// // audio.play();
// i implementend audio by js